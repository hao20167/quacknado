#include "simulation/simulation.hpp"
#include <Jolt/Core/Memory.h>
#include <Jolt/Core/Profiler.h>
#include <chrono>
#include <cstdio>
#include <stdexcept>
#include <string>
int main(int argc, char **argv) {
  using namespace JPH;
  try {
    size_t n = argc > 1 ? std::stoul(argv[1]) : 600;
    int workers = argc > 2 ? std::stoi(argv[2]) : 0;
    bool collision = argc > 3 ? std::stoi(argv[3]) != 0 : true;
    bool telemetry = argc > 4 ? std::stoi(argv[4]) != 0 : false;
    bool profile = argc > 5 ? std::stoi(argv[5]) != 0 : false;
    JPH::RegisterDefaultAllocator();
    if (profile) {
      JPH_PROFILE_START("interaction-main");
    }
    {
      Simulation sim(42, n, {workers, collision, telemetry});
      sim.profiling = true;
      sim.set_wind_enabled(true);
      std::puts("n,workers,collisions,telemetry,step,update_ns,wind_ns,physics_ns,active,dynamic_"
                "manifolds,static_manifolds,checksum");
      for (int step = 0; step < 360; ++step) {
        sim.set_tornado_direction({(step / 60) % 2 ? -1.f : 1.f, 0, 0});
        auto begin = std::chrono::steady_clock::now();
        sim.Update(1.f / 60);
        auto end = std::chrono::steady_clock::now();
        if (profile) {
          if (step == 180) {
            JPH_PROFILE_DUMP("interaction");
          }
          JPH_PROFILE_NEXTFRAME();
        }
        if (step < 60)
          continue;
        double sum = 0;
        for (const auto &o : sim.get_objects())
          if (!o->awaiting_spawn_)
            sum += o->position_.x + o->position_.y + o->position_.z;
        auto c = sim.contacts();
        std::printf("%zu,%d,%d,%d,%d,%.0f,%.0f,%.0f,%u,%u,%u,%.17g\n", n, workers, int(collision),
                    int(telemetry), step,
                    std::chrono::duration<double, std::nano>(end - begin).count(),
                    sim.timings.wind_ns, sim.timings.physics_ns, sim.active_body_count(), c.dynamic,
                    c.static_contacts, sum);
      }
    }
    if (profile) {
      JPH_PROFILE_END();
    }
  } catch (const std::exception &e) {
    std::fprintf(stderr, "%s\n", e.what());
    return 1;
  }
}
