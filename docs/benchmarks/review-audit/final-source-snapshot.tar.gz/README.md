# Quacknado

A native Apple Silicon C++20 tornado sandbox with Jolt rigid-body physics, SDL3,
Metal rendering, GLB instancing, and reproducible performance experiments.

The default scene requests 600 dynamic objects across several model types plus
scene props. Placement may defer objects when no space is available. Arrow keys
move the tornado; closing the window exits. Collision shapes and visual scale are
configured independently in `src/simulation/objs/obj_module.hpp`.

## Build and run

Requires macOS/Apple Silicon, Xcode with the Metal compiler, CMake 4.4+, Ninja,
and Python 3.10+. Tested with Apple M1 Pro, macOS 14.7.5 and Apple Clang 16.
Initialize the vendored submodules if starting from a fresh checkout:

```sh
git submodule update --init --recursive
cmake --preset perf
cmake --build --preset perf -j 8
ctest --preset perf
./build/perf/Release/quacknado
```

Run commands from the repository root. The full build copies models and shaders
next to the game executable. Benchmarks that load assets directly require the
repository root as their working directory.

## What the measurements establish

| Evidence | Result on the development machine | Scope |
|---|---|---|
| Calibrated wind kernel, 1M mixed samples | NEON + 4 workers about 6.65× over reference | Sample computation, not 1M rigid bodies |
| Actual windowed game | CPU submission about 0.266 → 0.084 ms | Frame median remained about 8.33 ms under presentation pacing |
| Integrated wind worker pool | Did not improve the measured small-scene pipeline | Direct path remains the game default |
| Memory probe | No intercepted C++ new calls in measured trajectories; Jolt still allocates | Does not establish zero allocations for the whole process |
| Renderer correctness | Mixed GLB pixel comparisons and fail-fast GPU sanitizer checks | Three-model regression fixture, not every possible scene |

See [the full report](docs/benchmarks/report.md) for raw-data locations, before/after
experiments, numerical tolerance, negative results and limitations. Historical
measurements identify their source versions; newer code is not assumed to reproduce
old timings exactly. This project demonstrates C++ ownership/templates/STL, SIMD,
concurrency, data structures and Python analysis. It does not currently include a
Python native binding, networking or an agentic LLM runtime.

## Reproduce an experiment

```sh
# Independent Python reference against 10,003 C++ force fixtures.
python3 scripts/check_reference.py

# CPU benchmark with correctness check and calibrated batches.
./build/perf/Release/quack_bench 10003 12 mixed neon --calibrated

# GPU pixel/resource-lifetime regression; requires a desktop Metal device.
MTL_DEBUG_LAYER=1 ./build/perf/Release/render_regression build/perf/Release/object.metallib

# Actual windowed replay; opens the game and exits after 210 frames.
QUACK_REPLAY_FRAMES=210 QUACK_REPLAY_MODE=instanced ./build/perf/Release/quacknado

# New campaign paths preserve recorded evidence. Choose unused directories.
python3 scripts/benchmark_calibrated.py --output /tmp/quack-cpu-campaign --no-report
python3 scripts/benchmark_windowed.py --output /tmp/quack-window-campaign
```

`quack_bench` arguments are `N repetitions dataset backend [--calibrated]`.
Calibration is supported for CPU kernels only. Backend `gpu` measures wind compute;
`glb` measures the actual GLB renderer (`dataset` is a model name such as `chicken`).
Campaign runners refuse to overwrite metadata/raw/summary in an existing output.
They assume one writer per output directory; use distinct directories for parallel
runs. They may update their numbered report section after a successful campaign.

## Validation and build structure

```sh
cmake --preset check
cmake --build --preset check -j 8
UBSAN_OPTIONS=halt_on_error=1 ASAN_OPTIONS=halt_on_error=1 ctest --preset check
UBSAN_OPTIONS=halt_on_error=1 ASAN_OPTIONS=halt_on_error=1 MTL_DEBUG_LAYER=1 \
  ./build/check/Debug/render_regression build/check/Debug/object.metallib
```

CPU tests are registered by default. GPU regression is run explicitly, or registered
with `-DQUACK_GPU_TESTS=ON` when configuring a machine with GPU access. The allocation
probe deliberately uses an uninstrumented simulation variant; Jolt/vendor code is
not claimed as sanitizer-covered. A separate TSan pool command is in the report.

`quack_sim` and `quack_render` are shared by the game and validation targets. CMake
source lists, shader/assets and test registration are in `cmake/`. Scalar reference,
SoA, NEON, worker-pool and GPU experiments retain comparable baselines. The game uses
pose-only sync, coalesced Jolt state reads and bounded GLB instancing batches.

The GLB loader supports the supplied static triangle assets, node transforms,
embedded PNG/JPEG textures and alpha masks. Animation, skinning, PBR lighting,
blended materials, external images and glTF extensions are outside its current scope.
