only physics simulation here: duck, tornado
- velocity, position, acceleration

